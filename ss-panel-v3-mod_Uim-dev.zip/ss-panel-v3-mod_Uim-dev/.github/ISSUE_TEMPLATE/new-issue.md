---
name: New Issue
about: Issue

---

<!--

如果你不填充下面的内容，我们可能会直接关闭你的 issue。

请在标题简单描述内容

如果你没有仔细阅读  Wiki ，或者无关问题，我们可能会直接关闭你的 issue。

注意：Wiki 可能随时都会更新。在提交一个 issue 前，请重新查看相关内容。
-->



**我确认我已经阅读了** (使用 "x" 选择)

- [ ] [项目 Wiki ](https://github.com/NimaQu/ss-panel-v3-mod_Uim/wiki)
- [ ] [项目其他 issue](https://github.com/NimaQu/ss-panel-v3-mod_Uim/issues?utf8=%E2%9C%93&q=is%3Aissue)

**我确认我做到了** (使用 "x" 选择)

- [ ] [将项目升级到当前分支最新版本](https://github.com/NimaQu/ss-panel-v3-mod_Uim/wiki/%E5%8D%87%E7%B4%9A%E7%89%88%E6%9C%AC)
- [ ] 在[项目演示站](https://demo.nimaqu.com)成功复现问题

**我正在申请**  (使用 "x" 选择)

- [ ] 反馈一个 bug
- [ ] 申请添加新的特性或功能或者好的想法



<!-- ----------- -->

**反馈BUG**

1.请在面板路径下运行`git show HEAD`，然后贴出输出内容

2.如果是页面问题（500 或 Slim Application Error )，请在 config 开启 debug 模式后截图或贴出输出内容，如果是某个按钮点击没反应，请打开浏览器开发者控制台（通常为 F12 ) ，贴出 console 输出内容

<!-- ----------- -->

**申请添加新的特性或功能或者好的想法**
