<?php

namespace App\Models;

class Link extends Model
{
    protected $connection = "default";
    protected $table = "link";
}
